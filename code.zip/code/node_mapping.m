function res = node_mapping(i,j,n)

    res = i + ( j - 1 ) .* n;
    
end