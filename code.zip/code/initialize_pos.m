function [x,y,vx,vy,vdx] = initialize_pos(l,w,mu,std,num_particles)

% randomly sample speeds from Gaussian distribution
vx = normrnd(mu,std,1,num_particles); 
vy = normrnd(mu,std,1,num_particles);

% define drift velocity in x-direction as the mean of our velocities in x-direction
vdx = mean(vx); 

% randomly sample positions from uniform distribution
x(1:num_particles) = rand(1,num_particles) * l;
y(1:num_particles) = rand(1,num_particles) * w;

end

